<?php
session_start();

$final=[];
for($i=0;$i<=3;$i++){
    $binario = rand(0, 1);
    $final[$i]=$binario;
    switch ($binario){
        case 0:
            echo"<img src=\"blanco.JPG\">";
            break;
        case 1:
            if($i==3)
            echo"<img src=\"uno.jpg\">";
            
            else if($i==2)
            echo"<img src=\"dos.JPG\">";
            
            if($i==1)
            echo"<img src=\"cuatro.JPG\">";
            
            if($i==0)
            echo"<img src=\"ocho.JPG\">";
            
            break;
        
        }
        echo $final[$i];
        $_SESSION["color"]= bindec($final[$i]);
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio2</title>
    <style>
        body {
            text-align: center;
            background-color: aliceblue;
        }
        .enviar {
            padding: 10px 20px;
            border-radius: 50px;
            font-size: 15px;
            cursor: pointer;
            transition: transform 0.5s ease;
        }
        .enviar:hover {
            transform: scale(1.2);
        }
    </style>
</head>
<body>
    <div>
        <p>Introduce el numero de arriba en binario:</p>
    <form action="ejercicio21.php" method="POST">
        <input type="text" id="color" name="color" required>
        <a href="ejercicio21.php">
             <input type="submit" value="Enviar">
        </a>
        </form>
 
    </div>
</body>
</html>
